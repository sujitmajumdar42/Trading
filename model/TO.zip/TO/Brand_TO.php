<?php

class BrandTO {

    public $Brand_Id;
    public $Brand_name;

    function setBrandID($brandID) {
        $this->Brand_Id = $brandID;
    }

    function getBrandID() {
        return $this->Brand_Id;
    }

    function setBrandName($brandName) {
        $this->Brand_name = $brandName;
    }

    function getBrandName() {
        return $this->Brand_name;
    }

}
?>


