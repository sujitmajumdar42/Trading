<?php

$brandID;
$productCat;
$PRD_ID;

function setBrandID($brandID) {
    $this->Brand_Id = $brandID;
}

function getBrandID() {
    return $this->Brand_Id;
}

function setProductCat($productCat) {
    $this->productCat = $productCat;
}

function getProductCat() {
    return $this->productCat;
}

function setProductID($productID) {
    $this->productID = $productID;
}

function getProductID() {
    return $this->productID;
}
