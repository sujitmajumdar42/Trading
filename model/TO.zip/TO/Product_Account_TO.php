<?php

$productId;
$BasicCost;
$Vat;
$Discount;

function setProductId($productId) {
    $this->productId = $productId;
}

function getProductId() {
    return $this->productId;
}

function setBasicCost($BasicCost) {
    $this->BasicCost = $BasicCost;
}

function getBasicCost() {
    return $this->BasicCost;
}

function setVat($Vat) {
    $this->Vat = $Vat;
}

function getVat() {
    return $this->Vat;
}

function setDiscount($Discount) {
    $this->Discount = $Discount;
}

function getDiscount() {
    return $this->Discount;
}
