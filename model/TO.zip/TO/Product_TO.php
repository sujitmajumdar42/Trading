<?php

class ProductTO {

    public $PRD_ID;
    public $PRD_NAME;

    function setProductID($productID) {
        $this->PRD_ID = $productID;
    }

    function getProductID() {
        return $this->PRD_ID;
    }

    function setProductName($productName) {
        $this->PRD_NAME = $productName;
    }

    function getProductName() {
        return $this->PRD_NAME;
    }

}
