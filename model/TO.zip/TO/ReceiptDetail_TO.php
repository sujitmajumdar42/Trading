<?php

$receiptID;
$date;
$totalAmount;
$receiptPath;

function setReceiptID($receiptID) {
    $this->receiptID = $receiptID;
}

function getReceiptID() {
    return $this->receiptID;
}

function setDate($date) {
    $this->date = $date;
}

function getDate() {
    return $this->date;
}

function setTotalAmount($totalAmount) {
    $this->totalAmount = $totalAmount;
}

function getTotalAmount() {
    return $this->totalAmount;
}

function setReceiptPath($receiptPath) {
    $this->receiptPath = $receiptPath;
}

function getReceiptPath() {
    return $this->receiptPath;
}
