<?php

$tradeID;
$PRD_ID;

function setTradeID($tradeID) {
    $this->tradeID = $tradeID;
}

function getTradeID() {
    return $this->tradeID;
}

function setProductID($productID) {
    $this->productID = $productID;
}

function getProductID() {
    return $this->productID;
}
