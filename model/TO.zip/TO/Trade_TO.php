<?php

$tradeID;
$tradeDate;
$tradeType;

function setTradeID($tradeID) {
    $this->tradeID = $tradeID;
}

function getTradeID() {
    return $this->tradeID;
}

function setTradeDate($tradeDate) {
    $this->tradeDate = $tradeDate;
}

function getTradeDate() {
    return $this->tradeDate;
}

function setTradeType($tradeType) {
    $this->tradeType = $tradeType;
}

function getTradeType() {
    return $this->tradeType;
}
