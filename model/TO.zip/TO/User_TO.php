<?php

$userName;
$password;
$name;
$role;
$lastLogin;

function setUserName($userName) {
    $this->userName = $userName;
}

function getUserName() {
    return $this->userName;
}

function setPassword($password) {
    $this->password = $password;
}

function getPassword() {
    return $this->password;
}

function setName($name) {
    $this->name = $name;
}

function getName() {
    return $this->name;
}

function setRole($role) {
    $this->role = $role;
}

function getRole() {
    return $this->role;
}

function setLastLogin($lastLogin) {
    $this->lastLogin = $lastLogin;
}

function getLastLogin() {
    return $this->lastLogin;
}

?>